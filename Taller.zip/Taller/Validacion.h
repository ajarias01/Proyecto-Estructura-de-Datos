#ifndef VALIDACION_H
#define VALIDACION_H

#include <string>
#include <cctype> // For std::isalpha, std::toupper, std::tolower
#include <iostream>
#include <conio.h> 

class Validacion {
public:
    string ingresar_alfabetico(const string& mensaje) {
        char c;
        string palabra;
        cout << mensaje;
        while (true) {
            c = getch();
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
                palabra += c;
                printf("%c", c);
            } else if (c == 13) { 
                return palabra;
            } else if (c == 8 && !palabra.empty()) { // Backspace
                palabra.pop_back();
                printf("\b \b");
            } else if (c == 27) { // ESC
                return "__ESC__"; // Valor especial para ESC
            }
        }
    }
    void limpiar_linea(const string& mensaje) {
        cout << "\r\033[K" << mensaje;
    }
    int ingresar_enteros(const string& mensaje) {
    char c;
    string palabra;
    cout << mensaje;
    while (true) {
        c = getch();
        if ((c>='0'&& c<='9') ) {
            palabra += c;
            printf("%c", c);
        } else if (c == 13) {
            return stoi(palabra);
        } else if (c == 8 && !palabra.empty()) { // Backspace
            palabra.pop_back();
            printf("\b \b");
        }
    }
}
    static bool soloLetrasLongitudMinima(const char* cadena, unsigned int longitudMinima) {
        if (!cadena || *cadena == '\0') {
            return false;
        }
        
        unsigned int contador = 0;
        const char* ptr = cadena;
        while (*ptr != '\0') {
            if (!std::isalpha(static_cast<unsigned char>(*ptr))) {
                return false;
            }
            contador++;
            ptr++;
        }
        
        return contador >= longitudMinima;
    }

    static bool soloLetras(const char* cadena) {
        if (!cadena || *cadena == '\0') {
            return false;
        }
        
        const char* ptr = cadena;
        while (*ptr != '\0') {
            if (!std::isalpha(static_cast<unsigned char>(*ptr))) {
                return false;
            }
            ptr++;
        }
        return true;
    }
    
    static bool soloLetras(const std::string& cadena) {
        return soloLetras(cadena.c_str());
    }
    
    
    static void aMayusculas(char* cadena) {
        if (!cadena) return;
        
        char* ptr = cadena;
        while (*ptr != '\0') {
            *ptr = std::toupper(static_cast<unsigned char>(*ptr));
            ptr++;
        }
    }
    
    static void aMinusculas(char* cadena) {
        if (!cadena) return;
        
        char* ptr = cadena;
        while (*ptr != '\0') {
            *ptr = std::tolower(static_cast<unsigned char>(*ptr));
            ptr++;
        }
    }
};

#endif // VALIDACION_H