#include <iostream>
#include <string>
using namespace std;
#include "OrdenamientoporLetras.h"
#include "Validacion.h"

int main()
{
    system("chcp 65001 > nul");
    int cantidad = 0;
    Validacion validacion;
    OrdenamientoporLetras ordenamiento;
    do {
        validacion.limpiar_linea("¿Cuántas personas desea registrar?: ");
        cantidad = validacion.ingresar_enteros("");
    } while (cantidad < 1);
    cout << endl;

    string *nombres = new string[cantidad];
    Persona *personas = new Persona[cantidad];
    for (int i = 0; i < cantidad; i++)
    {
        string nombre;
        bool nombreValido = false;
        
        do {
            validacion.limpiar_linea("Ingrese el nombre de la persona " + to_string(i + 1) + " (solo letras): ");
            nombre = validacion.ingresar_alfabetico("");

            // Validar que el nombre contenga solo letras
            nombreValido = Validacion::soloLetras(nombre);
        } while (!nombreValido);
        cout << endl;
        
        ordenamiento.ordenarLetrasNombreAscendente(nombre);
        personas[i] = Persona(nombre);
    }

    // Impresión de los nombres ordenados por letras ascendente
    cout << "Ordenamiento Alfabéticamente (ascendente):" << endl;
    for (int i = 0; i < cantidad; i++)
    {
        cout << "\t[" << personas[i].nombre << "]" << endl;
    }

    cout << "Ordenamiento Alfabéticamente (descendente):" << endl;
    // Ordenar los nombres por letras descendente
    for (int i = 0; i < cantidad; i++)
    {
        ordenamiento.ordenarLetrasNombreDescendente(personas[i].nombre);
        cout << "\t[" << personas[i].nombre << "]" << endl;
    }

    delete[] personas;
    delete[] nombres;
    return 0;
}