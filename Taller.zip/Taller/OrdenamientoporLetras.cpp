#include "Persona.h"
#include "OrdenamientoporLetras.h"
using namespace std;

// Helper function for counting sort based on a specific digit (character position)
void OrdenamientoporLetras::countingSortForRadix(char* inicio, char* final, bool ascending) {
    const int RANGE = 256; // ASCII character range
    int count[RANGE] = {0};
    char* output = new char[final - inicio];
    
    // Count occurrences of each character
    for (char* i = inicio; i < final; i++) {
        count[static_cast<unsigned char>(*i)]++;
    }
    
    if (ascending) {
        for (int i = 1; i < RANGE; i++) {
            count[i] += count[i - 1];
        }
    } else {
        for (int i = RANGE - 2; i >= 0; i--) {
            count[i] += count[i + 1];
        }
    }
    for (char* i = final - 1; i >= inicio; i--) {
        int index = ascending ? count[static_cast<unsigned char>(*i)] - 1 : count[static_cast<unsigned char>(*i)];
        output[index] = *i;
        count[static_cast<unsigned char>(*i)]--;
    }
    
    for (char* i = inicio, *j = output; i < final; i++, j++) {
        *i = *j;
    }
    
    delete[] output;
}

void OrdenamientoporLetras::ordenarLetrasNombreAscendente(string& nombre) {
    if (nombre.empty()) return;
    
    char* inicio = &nombre[0];
    char* final = inicio + nombre.length();
    
    countingSortForRadix(inicio, final, true);
}

void OrdenamientoporLetras::ordenarLetrasNombreDescendente(string& nombre) {
    if (nombre.empty()) return;
    
    char* inicio = &nombre[0];
    char* final = inicio + nombre.length();
    
    // Use counting sort with descending order
    countingSortForRadix(inicio, final, false);
}

// Function to sort characters within each person's name
void OrdenamientoporLetras::ordenarLetrasDeNombres(Persona* personas, int cantidad) {
    Persona* final = personas + cantidad;
    
    // Iterate through each person and sort their name's characters
    for (Persona* p = personas; p < final; p++) {
        ordenarLetrasNombreAscendente(p->nombre);
    }
}