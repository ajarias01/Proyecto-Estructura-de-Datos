#ifndef ORDENAMIENTOPORLETRAS_H
#define ORDENAMIENTOPORLETRAS_H

#include <string>
#include "Persona.h"
#include <iostream>

class OrdenamientoporLetras
{
public:
void countingSortForRadix(char*, char*, bool);
void ordenarLetrasNombreAscendente(std::string&);
void ordenarLetrasNombreDescendente(std::string&);
void ordenarLetrasDeNombres(Persona*, int);
};


#endif